﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    abstract class Empregado
    {
        private int matricula; // atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;
        private char homeOffice;

        /* privado = escondido = encapsulado
        atributos = características */

        public int Matricula // propriedade
        {
            get { return matricula; }   /* propriedades para usar atributos encapsulados */
            set { matricula = value; }
        }

        /* público = pode ser visto fora da classe */

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public Char HomeOffice
        {
            get { return homeOffice; }
            set { homeOffice = value; }
        }

        // método = ações/comportamentos

        public String VerificaHome() // método
        {
            if (homeOffice == 'S')
                return "Empregado trabalha em home office";
            else
                return "Empregado NÃO trabalha em home office";
        }

        // virtual -> pode ser sobreescrito

        public virtual int TempoTrabalho()
        {
            // representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa); /* tipo de dado que guardar permite intervalos de tempo; subtração entre datas (entrada na empresa, atual) */

            return (span.Days);
        }

        // deve ser implementado nas classes filhas (subclasses)

        public abstract double SalarioBruto(); // não preciso implementar

        /* abstrato não pode fazer objetos */
    }
}
