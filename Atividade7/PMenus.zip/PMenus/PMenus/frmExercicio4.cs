﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMenus
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCaracNum_Click(object sender, EventArgs e)
        {
            int qtdNum = 0;
            char[] frase = rchtxtFrase.Text.ToCharArray();

            for (var i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (Char.IsNumber(frase[i]))
                {
                    qtdNum++;
                }
            }
            MessageBox.Show("Existem " + qtdNum.ToString("N0") + " caracteres numéricos");
        }

        private void btnCaracAlfa_Click(object sender, EventArgs e)
        {
            int qtdLetra = 0;
            char[] frase = rchtxtFrase.Text.ToCharArray();

            foreach (var caracter in frase)
            {
                if (Char.IsLetter(caracter))
                {
                    qtdLetra++;
                }
            }
            MessageBox.Show("Existem " + qtdLetra.ToString("N0") + " caracteres alfabéticos");
        }

        private void btnCaracBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0, i = 0;
            char[] frase = rchtxtFrase.Text.ToCharArray();

            while (!Char.IsWhiteSpace(frase[i]))
            {
                i++;
            }

            posicao = i;
            MessageBox.Show("O primeiro caracter branco está na posição " + posicao.ToString("N0"));
        }
    }
}
