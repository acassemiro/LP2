﻿namespace PMenus
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.btnInverte = new System.Windows.Forms.Button();
            this.btnRmvOcorrenciasRpc = new System.Windows.Forms.Button();
            this.btnRmvOcorrencias = new System.Windows.Forms.Button();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblPalavra2
            // 
            this.lblPalavra2.AutoSize = true;
            this.lblPalavra2.Location = new System.Drawing.Point(117, 100);
            this.lblPalavra2.Name = "lblPalavra2";
            this.lblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra2.TabIndex = 13;
            this.lblPalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(117, 61);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblPalavra1.TabIndex = 12;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // btnInverte
            // 
            this.btnInverte.Location = new System.Drawing.Point(120, 241);
            this.btnInverte.Name = "btnInverte";
            this.btnInverte.Size = new System.Drawing.Size(210, 23);
            this.btnInverte.TabIndex = 11;
            this.btnInverte.Text = "Inverte (reverse)";
            this.btnInverte.UseVisualStyleBackColor = true;
            this.btnInverte.Click += new System.EventHandler(this.btnInverte_Click);
            // 
            // btnRmvOcorrenciasRpc
            // 
            this.btnRmvOcorrenciasRpc.Location = new System.Drawing.Point(120, 212);
            this.btnRmvOcorrenciasRpc.Name = "btnRmvOcorrenciasRpc";
            this.btnRmvOcorrenciasRpc.Size = new System.Drawing.Size(210, 23);
            this.btnRmvOcorrenciasRpc.TabIndex = 10;
            this.btnRmvOcorrenciasRpc.Text = "Remove Ocorrências (replace)";
            this.btnRmvOcorrenciasRpc.UseVisualStyleBackColor = true;
            this.btnRmvOcorrenciasRpc.Click += new System.EventHandler(this.btnRmvOcorrenciasRpc_Click);
            // 
            // btnRmvOcorrencias
            // 
            this.btnRmvOcorrencias.Location = new System.Drawing.Point(120, 180);
            this.btnRmvOcorrencias.Name = "btnRmvOcorrencias";
            this.btnRmvOcorrencias.Size = new System.Drawing.Size(210, 23);
            this.btnRmvOcorrencias.TabIndex = 9;
            this.btnRmvOcorrencias.Text = "Remove Ocorrências";
            this.btnRmvOcorrencias.UseVisualStyleBackColor = true;
            this.btnRmvOcorrencias.Click += new System.EventHandler(this.btnRmvOcorrencias_Click);
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(195, 100);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(135, 20);
            this.txtPalavra2.TabIndex = 8;
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(195, 61);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(135, 20);
            this.txtPalavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 411);
            this.Controls.Add(this.lblPalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Controls.Add(this.btnInverte);
            this.Controls.Add(this.btnRmvOcorrenciasRpc);
            this.Controls.Add(this.btnRmvOcorrencias);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Name = "frmExercicio3";
            this.Text = "Exercício 3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra2;
        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Button btnInverte;
        private System.Windows.Forms.Button btnRmvOcorrenciasRpc;
        private System.Windows.Forms.Button btnRmvOcorrencias;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
    }
}