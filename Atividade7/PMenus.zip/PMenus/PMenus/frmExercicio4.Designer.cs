﻿namespace PMenus
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCaracAlfa = new System.Windows.Forms.Button();
            this.btnCaracBranco = new System.Windows.Forms.Button();
            this.btnCaracNum = new System.Windows.Forms.Button();
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // btnCaracAlfa
            // 
            this.btnCaracAlfa.Location = new System.Drawing.Point(160, 294);
            this.btnCaracAlfa.Margin = new System.Windows.Forms.Padding(4);
            this.btnCaracAlfa.Name = "btnCaracAlfa";
            this.btnCaracAlfa.Size = new System.Drawing.Size(280, 28);
            this.btnCaracAlfa.TabIndex = 7;
            this.btnCaracAlfa.Text = "Quantidade de Caracteres Alfabéticos";
            this.btnCaracAlfa.UseVisualStyleBackColor = true;
            this.btnCaracAlfa.Click += new System.EventHandler(this.btnCaracAlfa_Click);
            // 
            // btnCaracBranco
            // 
            this.btnCaracBranco.Location = new System.Drawing.Point(160, 258);
            this.btnCaracBranco.Margin = new System.Windows.Forms.Padding(4);
            this.btnCaracBranco.Name = "btnCaracBranco";
            this.btnCaracBranco.Size = new System.Drawing.Size(280, 28);
            this.btnCaracBranco.TabIndex = 6;
            this.btnCaracBranco.Text = "Posição primeiro Caracter Branco";
            this.btnCaracBranco.UseVisualStyleBackColor = true;
            this.btnCaracBranco.Click += new System.EventHandler(this.btnCaracBranco_Click);
            // 
            // btnCaracNum
            // 
            this.btnCaracNum.Location = new System.Drawing.Point(160, 222);
            this.btnCaracNum.Margin = new System.Windows.Forms.Padding(4);
            this.btnCaracNum.Name = "btnCaracNum";
            this.btnCaracNum.Size = new System.Drawing.Size(280, 28);
            this.btnCaracNum.TabIndex = 5;
            this.btnCaracNum.Text = "Quantidade de Caracteres Numéricos";
            this.btnCaracNum.UseVisualStyleBackColor = true;
            this.btnCaracNum.Click += new System.EventHandler(this.btnCaracNum_Click);
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(156, 75);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(279, 70);
            this.rchtxtFrase.TabIndex = 8;
            this.rchtxtFrase.Text = "";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(579, 506);
            this.Controls.Add(this.rchtxtFrase);
            this.Controls.Add(this.btnCaracAlfa);
            this.Controls.Add(this.btnCaracBranco);
            this.Controls.Add(this.btnCaracNum);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnCaracAlfa;
        private System.Windows.Forms.Button btnCaracBranco;
        private System.Windows.Forms.Button btnCaracNum;
        private System.Windows.Forms.RichTextBox rchtxtFrase;
    }
}