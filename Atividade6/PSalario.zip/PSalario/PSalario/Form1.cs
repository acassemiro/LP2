﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;

            double descINSS = 0;
            double descIRPF = 0;
            double salLiquido = 0;
            double salBruto = 0;
            double salFamilia = 0;
            double filhos = 0;

            if (txtNome.Text == String.Empty) // validação nome vazio
                MessageBox.Show("O nome do funcionário\nnão pode ser vazio");
            else
            {
                if (mskbxSalBruto.Text.Replace(",","").Trim()=="") // validação sal bruto vazio
                    MessageBox.Show("Não digitou salário");

                else if (!double.TryParse(mskbxSalBruto.Text, out salBruto)) // validação sal bruto não numérico
                    MessageBox.Show("Salário bruto deve ser um número");
                else
                {
                    if (salBruto <= 0) // validação sal bruto negativo
                        MessageBox.Show("Salário bruto deve ser maior que 0");

                    else
                    {
                        // cálculo INSS
                        if (salBruto <= 800.47)
                        {
                            txtAliqINSS.Text = "7,65%";
                            descINSS = 0.0765 * salBruto;
                        }
                        else if (salBruto <= 1050)
                        {
                            txtAliqINSS.Text = "8,65%";
                            descINSS = 0.0865 * salBruto;
                        }
                        else if (salBruto <= 1400.77)
                        {
                            txtAliqINSS.Text = "9,00%";
                            descINSS = 0.09 * salBruto;
                        }
                        else if (salBruto <= 2801.56)
                        {
                            txtAliqINSS.Text = "11,00%";
                            descINSS = 0.11 * salBruto;
                        }
                        else
                        {
                            txtAliqINSS.Text = "Teto";
                            descINSS = 308.17;
                        }

                        txtDescINSS.Text = descINSS.ToString("N2");

                        // cálculo IRPF
                        if (salBruto <= 1257.12)
                            txtAliqIRPF.Text = "0";
                        else if (salBruto <= 2512.08)
                        {
                            txtAliqIRPF.Text = "15%";
                            descIRPF = 0.15 * salBruto;
                        }
                        else
                        {
                            txtAliqIRPF.Text = "27,5%";
                            descIRPF = 0.275 * salBruto;
                        }

                        txtDescIRPF.Text = descIRPF.ToString("N2");

                        // cálculo sal família
                        filhos = Convert.ToDouble((decimal)nupdFilhos.Value);

                        if (filhos > 0)
                        {
                            if (salBruto <= 435.52)
                                salFamilia = 22.33 * filhos;
                            else if (salBruto <= 654.61)
                                salFamilia = 15.74 * filhos;
                            else
                                salFamilia = 0;
                        }

                        txtSalFamilia.Text = salFamilia.ToString("N2");

                        // cálculo sal líquido
                        salLiquido = salBruto - descINSS - descIRPF + salFamilia;

                        txtSalLiquido.Text = salLiquido.ToString("N2");

                        // exibir dados
                        lblDados.Text = "Os descontos do salário " + (rbtnF.Checked ? "da Sra. " : "do Sr. ") + txtNome.Text +
                            " que é " + (ckbxCasado.Checked ? "Casado(a)" : "Solteiro(a)") +
                            " e que tem " + Convert.ToString(filhos) + " filho(s) são:";
                    }
                }
            }
        }
    }
}
